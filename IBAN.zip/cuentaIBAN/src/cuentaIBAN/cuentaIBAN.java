package cuentaIBAN;

import java.math.BigInteger;
import java.util.Scanner;

public class cuentaIBAN {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		boolean tamanoCheck = false;
		
		String userIBAN = "ES28 2100 3894 42 0200039542";
		
		do {
		System.out.println("Por favor, introduce tu IBAN: "); //String userIBAN = sc.nextLine();
		userIBAN = userIBAN.replaceAll(" ", "");
		System.out.println(userIBAN);
		if (userIBAN.length() == 24 && Character.isLetter(userIBAN.charAt(0)) == true && Character.isLetter(userIBAN.charAt(1)) == true) {
			tamanoCheck = true;
		}}while (tamanoCheck == false);
		
		boolean verif = cuentaIBAN.verifIBAN(userIBAN);
		System.out.println(verif);

	}
	
	public static boolean verifIBAN(String userIban) {
		
		String check00 = userIban.substring(2,4);
		String checkD = userIban.substring(4, 12);
		
		//Genero el numero sin ES28 y con la info del final.
		String VerifuserIban = userIban.substring(4,24) + "142800";
		BigInteger bigInt, divide, R;
		bigInt = new BigInteger(VerifuserIban);
		divide = new BigInteger("97");
		R  = bigInt.remainder(divide);
		int Rfinal = 98-R.intValue();
		
		//Verificar primer digito de control D
		
		int[] vectorVerifRestos = {1,2,4,8,5,10,9,7,3,6};
		int  D = 0;
		
		System.out.println(checkD);
		
		for (int i = 0; i < checkD.length(); i++) {
			System.out.println("La multi es: " + vectorVerifRestos[i] +"*"+ Character.getNumericValue(checkD.charAt(i)));
			D =  D + (vectorVerifRestos[i] * Character.getNumericValue(checkD.charAt(i)));
		}
		
		D = 11 - (D%11);
		
		System.out.println(D);
		
		if (Rfinal == Integer.parseInt(check00)) {
			return true;
		}else {
			return false;
		}
	}
	
	//Formato IBAN: ESIIEEEESSSSDCNNNNNNNNNN -> 24 caracteres.
	
	String[] bancos = {
			"2100 La Caixa",
			"0081 Sabadell",
			"2038 Bankia",
			"3058 Cajamar",
			"0019 Deutsche Bank",
			"0239 Evo",
			"2095 Kitxabank",
			"0049 Banco Santander",
			"0057 BBVA",
			};
	
	String[] sucursales = {
			"2286 Urbana 1",
			"2288 Urbana 2",
			"2289 Urbana 3",
			"2296 Altabix 1",
			"2298 Altabix 2",
			"2311 Altabix 3",
			"2144 Carrus Este",
			"2145 Carrus Sur",
			"2009 Pla 11",
			"2010 Pla 12",
	};
	
	/*public static boolean verificarIBAN(String iban){
		
		boolean ES, II, EEEE, SSSS, D, C, NNNNNNNNNN, CCC;
		
		ES = verifNac(iban);
		
		if (ES == true && II == true && EEEE == true && SSSS == true && D == true &&  C == true && NNNNNNNNNN ==  true && CCC == true) {
			return true;
		}
	}
	
	public static boolean verifNac(String iban) {
		String result = iban.substring(0,2);
		if (result.equals("ES")) {
			return true;
		} else {
			return false;
		}
	}
	
	public static boolean verifBankSucur(String iban) {
		String result = iban.substring(4,8);
		int A = 0;
		A = result.charAt(0) * 4;
		A = A + Character.getNumericValue(result.charAt(1)) * 8;
		A = A + Character.getNumericValue(result.charAt(2)) * 5;
		A = A + Character.getNumericValue(result.charAt(3)) * 10;
		return true;
	}*/

}
