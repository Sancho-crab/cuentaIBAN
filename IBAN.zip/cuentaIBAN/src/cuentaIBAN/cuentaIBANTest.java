package cuentaIBAN;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class cuentaIBANTest {

	
	@Test
	void verifBankSucur() {
		String variable = "11284585";
		int exp = 146;
		String result = variable.substring(4,8);
		int A = 0;
		A = Character.getNumericValue(result.charAt(0)) * 4;
		A = A + Character.getNumericValue(result.charAt(1)) * 8;
		A = A + Character.getNumericValue(result.charAt(2)) * 5;
		A = A + Character.getNumericValue(result.charAt(3)) * 10;
		assertEquals(exp, A);
}

}
